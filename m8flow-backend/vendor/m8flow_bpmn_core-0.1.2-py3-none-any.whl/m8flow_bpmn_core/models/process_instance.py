from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy.orm import (
    Mapped,
    mapped_column,
    object_session,
    relationship,
    validates,
)

from m8flow_bpmn_core.models.base import Base
from m8flow_bpmn_core.models.json_data import JsonDataModel
from m8flow_bpmn_core.models.tenant_scoped import M8fTenantScopedMixin, TenantScoped

WORKFLOW_STATE_JSON_DATA_KEY = "__m8f_workflow_state_json"


class ProcessInstanceStatus(StrEnum):
    complete = "complete"
    error = "error"
    not_started = "not_started"
    running = "running"
    suspended = "suspended"
    terminated = "terminated"
    user_input_required = "user_input_required"
    waiting = "waiting"


class ProcessInstanceModel(M8fTenantScopedMixin, TenantScoped, Base):
    __tablename__ = "process_instance"
    id: Mapped[int] = mapped_column(primary_key=True)
    process_model_identifier: Mapped[str] = mapped_column(
        String(255), index=True, nullable=False
    )
    process_model_display_name: Mapped[str] = mapped_column(
        String(255), index=True, nullable=False
    )
    summary: Mapped[str | None] = mapped_column(String(255))
    process_initiator_id: Mapped[int] = mapped_column(
        ForeignKey("user.id"), index=True, nullable=False
    )
    bpmn_process_definition_id: Mapped[int | None] = mapped_column(
        ForeignKey("bpmn_process_definition.id"),
        index=True,
    )
    bpmn_process_id: Mapped[int | None] = mapped_column(
        ForeignKey("bpmn_process.id"),
        index=True,
    )
    spiff_serializer_version: Mapped[str | None] = mapped_column(String(50))
    status: Mapped[str] = mapped_column(
        String(50), index=True, nullable=False, default="running"
    )
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    ended_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    task_updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    bpmn_version_control_type: Mapped[str | None] = mapped_column(String(50))
    bpmn_version_control_identifier: Mapped[str | None] = mapped_column(String(255))
    last_milestone_bpmn_name: Mapped[str | None] = mapped_column(
        String(255), index=True
    )
    bpmn_version_id: Mapped[int | None] = mapped_column(
        ForeignKey("process_model_bpmn_version.id"),
        index=True,
    )

    process_initiator = relationship("UserModel")
    bpmn_process_definition = relationship("BpmnProcessDefinitionModel")
    bpmn_process = relationship("BpmnProcessModel")
    tasks = relationship(
        "TaskModel", back_populates="process_instance", cascade="all, delete-orphan"
    )
    human_tasks = relationship(
        "HumanTaskModel",
        back_populates="process_instance",
        cascade="all, delete-orphan",
        overlaps="active_human_tasks",
    )
    active_human_tasks = relationship(
        "HumanTaskModel",
        primaryjoin=(
            "and_(HumanTaskModel.process_instance_id == ProcessInstanceModel.id, "
            "HumanTaskModel.completed == False)"
        ),
        viewonly=True,
        overlaps="human_tasks",
    )
    process_instance_events = relationship(
        "ProcessInstanceEventModel",
        back_populates="process_instance",
        cascade="all, delete-orphan",
    )
    process_metadata = relationship(
        "ProcessInstanceMetadataModel",
        back_populates="process_instance",
        cascade="all, delete-orphan",
    )
    scheduler_jobs = relationship(
        "SchedulerJobModel",
        back_populates="process_instance",
        cascade="all, delete-orphan",
    )

    def can_submit_task(self) -> bool:
        return not self.has_terminal_status() and self.status != "suspended"

    def allowed_to_run(self) -> bool:
        return not self.has_terminal_status() and self.status != "suspended"

    def can_receive_message(self) -> bool:
        return not self.has_terminal_status() and self.status != "suspended"

    def has_terminal_status(self) -> bool:
        return self.status in self.terminal_statuses()

    def is_immediately_runnable(self) -> bool:
        return self.status in self.immediately_runnable_statuses()

    @classmethod
    def terminal_statuses(cls) -> list[str]:
        return ["complete", "error", "terminated"]

    @classmethod
    def non_terminal_statuses(cls) -> list[str]:
        terminal_status_values = cls.terminal_statuses()
        return [
            status.value
            for status in ProcessInstanceStatus
            if status.value not in terminal_status_values
        ]

    @classmethod
    def active_statuses(cls) -> list[str]:
        return cls.immediately_runnable_statuses() + ["user_input_required", "waiting"]

    @classmethod
    def immediately_runnable_statuses(cls) -> list[str]:
        return ["not_started", "running"]

    @validates("status")
    def validate_status(self, key: str, value: Any) -> Any:
        return ProcessInstanceStatus(value).value

    @property
    def workflow_state_json(self) -> str | None:
        if self.bpmn_process is None:
            return None
        session = object_session(self)
        if session is None:
            return None
        json_data = JsonDataModel.get_for_tenant(
            session,
            self.bpmn_process.m8f_tenant_id,
            self.bpmn_process.json_data_hash,
        )
        if json_data is None:
            return None
        value = json_data.data.get(WORKFLOW_STATE_JSON_DATA_KEY)
        return value if isinstance(value, str) else None
